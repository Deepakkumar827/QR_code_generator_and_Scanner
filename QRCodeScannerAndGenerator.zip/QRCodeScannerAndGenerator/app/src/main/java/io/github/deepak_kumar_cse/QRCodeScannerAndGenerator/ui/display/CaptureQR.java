package io.github.deepak_kumar_cse.QRCodeScannerAndGenerator.ui.display;

import com.journeyapps.barcodescanner.CaptureActivity;

public class CaptureQR extends CaptureActivity
{
}